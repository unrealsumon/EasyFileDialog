// Copyright 2017-2020 Firefly Studio. All Rights Reserved.


#include "EFDCore.h"
#include "DesktopPlatform/Public/DesktopPlatformModule.h"

bool EFDCore::OpenFileDialogCore(const FString& DialogTitle, const FString& DefaultPath, const FString& DefaultFile, const FString& FileTypes, uint32 Flags, TArray< FString >& OutFilenames)
{
	// Calling the main open file dialog function using UE4's FDesktopPlatformModule struct.
	return FDesktopPlatformModule::Get()->OpenFileDialog(nullptr, DialogTitle, DefaultPath, DefaultFile, FileTypes, Flags, OutFilenames);
}


bool EFDCore::SaveFileDialogCore(const FString& DialogTitle, const FString& DefaultPath, const FString& DefaultFile, const FString& FileTypes, uint32 Flags, TArray< FString >& OutFilenames)
{
	// Calling the main save file dialog function using UE4's FDesktopPlatformModule struct.
	return FDesktopPlatformModule::Get()->SaveFileDialog(nullptr, DialogTitle, DefaultPath, DefaultFile, FileTypes, Flags, OutFilenames);
}

bool EFDCore::OpenFolderDialogCore(const FString& DialogTitle, const FString& DefaultPath, FString& OutFoldername)
{
	// Calling the main open folder dialog function using UE4's FDesktopPlatformModule struct.
	return FDesktopPlatformModule::Get()->OpenDirectoryDialog(nullptr, DialogTitle, DefaultPath, OutFoldername);
}
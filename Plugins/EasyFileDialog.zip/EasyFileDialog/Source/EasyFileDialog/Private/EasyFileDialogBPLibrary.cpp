// Copyright 2017-2020 Firefly Studio. All Rights Reserved.

#include "EasyFileDialogBPLibrary.h"
#include "EasyFileDialog.h"

UEasyFileDialogBPLibrary::UEasyFileDialogBPLibrary(const FObjectInitializer& ObjectInitializer)
: Super(ObjectInitializer)
{

}

float UEasyFileDialogBPLibrary::EasyFileDialogSampleFunction(float Param)
{
	return -1;
}

